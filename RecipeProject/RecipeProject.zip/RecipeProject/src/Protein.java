public class Protein extends Ingredients {
    private String name;
    public Protein(String name){
        this.name = name;
    }


}
