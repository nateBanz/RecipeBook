public class Condiments extends Ingredients {
    private String name;
    public Condiments(String name){
        this.name = name;
    }


}
