public class Dairy extends Ingredients {
    private String name;
    public Dairy(String name){
        this.name = name;
    }

}
