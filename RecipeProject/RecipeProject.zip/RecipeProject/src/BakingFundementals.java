public class BakingFundementals extends Ingredients {
    private String name;
    public BakingFundementals(String name){
        this.name = name;
    }

}
